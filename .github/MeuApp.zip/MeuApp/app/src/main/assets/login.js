// Alternar entre login e cadastro
document.getElementById('showRegister').addEventListener('click', function(e) {
    e.preventDefault();
    document.querySelector('.login-form').style.display = 'none';
    document.querySelector('.register-form').style.display = 'block';
});

document.getElementById('showLogin').addEventListener('click', function(e) {
    e.preventDefault();
    document.querySelector('.register-form').style.display = 'none';
    document.querySelector('.login-form').style.display = 'block';
});

// Mostrar/ocultar senha
document.getElementById('togglePassword').addEventListener('click', function() {
    const passwordInput = document.getElementById('password');
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        this.textContent = '🔒';
    } else {
        passwordInput.type = 'password';
        this.textContent = '👁️';
    }
});

// Validação de senha
document.getElementById('regPassword').addEventListener('input', function() {
    const password = this.value;
    const constraints = document.getElementById('password-constraints');
    let message = '';
    
    if (password.length < 8) message += '❌ Mínimo 8 caracteres. ';
    if (!/[A-Z]/.test(password)) message += '❌ Uma maiúscula. ';
    if (!/[a-z]/.test(password)) message += '❌ Uma minúscula.';
    
    constraints.textContent = message || '✅ Senha válida!';
    constraints.style.color = message ? '#f44336' : '#4caf50';
});

// Cadastro
document.getElementById('registerForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const name = document.getElementById('regName').value;
    const email = document.getElementById('regEmail').value;
    const password = document.getElementById('regPassword').value;
    const confirm = document.getElementById('regConfirm').value;
    
    if (!name || !email || !password || !confirm) {
        alert('Preencha todos os campos!');
        return;
    }
    
    if (password !== confirm) {
        alert('As senhas não coincidem!');
        return;
    }
    
    // Validações
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('E-mail inválido!');
        return;
    }
    
    if (password.length < 8 || !/[A-Z]/.test(password) || !/[a-z]/.test(password)) {
        alert('A senha deve ter 8+ caracteres, maiúscula e minúscula!');
        return;
    }
    
    // Verificar se usuário já existe
    let users = JSON.parse(localStorage.getItem('users')) || [];
    if (users.some(u => u.email === email)) {
        alert('E-mail já cadastrado!');
        return;
    }
    
    // Salvar novo usuário (senha em base64 - apenas exemplo!)
    users.push({
        id: Date.now(),
        name: name,
        email: email,
        password: btoa(password)
    });
    
    localStorage.setItem('users', JSON.stringify(users));
    alert('Cadastro realizado! Faça login.');
    document.querySelector('.register-form').style.display = 'none';
    document.querySelector('.login-form').style.display = 'block';
});

// Login
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const remember = document.getElementById('remember').checked;
    
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(u => u.email === email && u.password === btoa(password));
    
    if (user) {
        localStorage.setItem('currentUser', JSON.stringify({
            id: user.id,
            name: user.name,
            email: user.email
        }));
        
        if (remember) {
            localStorage.setItem('rememberUser', 'true');
        }
        
        // Redirecionar para o app principal
        window.location.href = 'app.html';
    } else {
        alert('E-mail ou senha incorretos!');
    }
});

// Verificar se já está logado
window.addEventListener('load', function() {
    const currentUser = localStorage.getItem('currentUser');
    const remember = localStorage.getItem('rememberUser');
    
    if (currentUser && remember) {
        window.location.href = 'app.html';
    }
});