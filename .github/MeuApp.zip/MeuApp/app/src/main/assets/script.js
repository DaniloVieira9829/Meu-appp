// Exemplo de adaptação no seu script original
function getCurrentUserId() {
    const user = JSON.parse(localStorage.getItem('currentUser'));
    return user ? user.id : null;
}

// Ao carregar dados
function carregarReceitas() {
    const userId = getCurrentUserId();
    if (!userId) {
        window.location.href = 'login.html';
        return;
    }
    let receitas = JSON.parse(localStorage.getItem(`receitas_${userId}`)) || [];
    // ... resto do código
}

// Ao salvar dados
function salvarReceita(receita) {
    const userId = getCurrentUserId();
    let receitas = JSON.parse(localStorage.getItem(`receitas_${userId}`)) || [];
    receitas.push(receita);
    localStorage.setItem(`receitas_${userId}`, JSON.stringify(receitas));
}

// Função de logout (adicione um botão no seu app)
function logout() {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('rememberUser');
    window.location.href = 'login.html';
}