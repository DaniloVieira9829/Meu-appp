package com.seuapp

import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    
    private lateinit var webView: WebView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        webView = findViewById(R.id.webview)
        
        // Configurações do WebView
        val webSettings: WebSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true  // Necessário para localStorage
        webSettings.allowFileAccess = true
        webSettings.setAppCacheEnabled(true)
        webSettings.loadWithOverviewMode = true
        webSettings.useWideViewPort = true
        
        // Forçar links a abrirem dentro do WebView
        webView.webViewClient = WebViewClient()
        
        // Carregar o arquivo HTML da pasta assets
        webView.loadUrl("file:///android_asset/login.html")
    }
    
    // Lidar com o botão voltar
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}